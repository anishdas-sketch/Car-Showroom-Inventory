package showroom.main;

import showroom.gui.ShowroomGUI;

public class MainApp {
    public static void main(String[] args) {
        new ShowroomGUI();
    }
}
