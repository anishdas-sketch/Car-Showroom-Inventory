package showroom.service;

import showroom.model.CarModel;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class InventoryService {
    private List<CarModel> inventory;
    private final String CSV_FILE = "data/inventory.csv";

    public InventoryService() {
        inventory = new ArrayList<>();
        loadInventory();
    }

    private void loadInventory() {
        File file = new File(CSV_FILE);
        file.getParentFile().mkdirs();
        try {
            if (!file.exists()) file.createNewFile();
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                CarModel car = CarModel.fromCSV(line);
                if (car != null) inventory.add(car);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveInventory() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(CSV_FILE))) {
            for (CarModel car : inventory) {
                bw.write(car.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addCarModel(CarModel car) {
        inventory.add(car);
        saveInventory();
    }

    public void removeCarModel(String brand, String model) {
        inventory.removeIf(c -> c.getBrand().equalsIgnoreCase(brand) && c.getModel().equalsIgnoreCase(model));
        saveInventory();
    }

    public void updateCarModel(CarModel car, String newBrand, String newModel, double newPrice, int newQty, String newImage) {
        car.setBrand(newBrand);
        car.setModel(newModel);
        car.setPrice(newPrice);
        car.setQuantity(newQty);
        car.setImagePath(newImage);
        saveInventory();
    }

    public void sellCar(String brand, String model) {
        for (CarModel c : inventory) {
            if (c.getBrand().equalsIgnoreCase(brand) && c.getModel().equalsIgnoreCase(model)) {
                if (c.getQuantity() > 0) c.setQuantity(c.getQuantity() - 1);
                break;
            }
        }
        saveInventory();
    }

    public List<String> getAllBrands() {
        return inventory.stream().map(CarModel::getBrand).distinct().collect(Collectors.toList());
    }

    public List<CarModel> getModelsByBrand(String brand) {
        return inventory.stream().filter(c -> c.getBrand().equalsIgnoreCase(brand)).collect(Collectors.toList());
    }

    public CarModel getCarModel(String brand, String model) {
        for (CarModel c : inventory) {
            if (c.getBrand().equalsIgnoreCase(brand) && c.getModel().equalsIgnoreCase(model))
                return c;
        }
        return null;
    }

    public static String formatPrice(double price) {
        if (price >= 1_00_00_000) return String.format("%.2f Cr", price / 1_00_00_000);
        else if (price >= 1_00_000) return String.format("%.2f L", price / 1_00_000);
        else return String.format("%.0f", price);
    }
}
