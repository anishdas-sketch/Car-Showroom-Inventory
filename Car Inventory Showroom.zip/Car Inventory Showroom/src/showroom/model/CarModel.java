package showroom.model;

public class CarModel {
    private String brand;
    private String model;
    private double price;
    private int quantity;
    private String imagePath;

    public CarModel(String brand, String model, double price, int quantity, String imagePath) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.quantity = quantity;
        this.imagePath = imagePath;
    }

    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public String getImagePath() { return imagePath; }

    public void setBrand(String brand) { this.brand = brand; }
    public void setModel(String model) { this.model = model; }
    public void setPrice(double price) { this.price = price; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    @Override
    public String toString() {
        return brand + "," + model + "," + price + "," + quantity + "," + imagePath;
    }

    public static CarModel fromCSV(String line) {
        String[] parts = line.split(",");
        if (parts.length < 5) return null;
        return new CarModel(parts[0], parts[1], Double.parseDouble(parts[2]), Integer.parseInt(parts[3]), parts[4]);
    }
}
