package showroom.model;

import java.util.*;

public class Inventory {
    private List<CarModel> models = new ArrayList<>();

    public void addModel(CarModel model) { models.add(model); }

    public void removeModel(CarModel model) { models.remove(model); }

    public List<CarModel> getAllModels() { return models; }

    public List<String> getAllBrands() {
        Set<String> brands = new LinkedHashSet<>();
        for (CarModel m : models) brands.add(m.getBrand());
        return new ArrayList<>(brands);
    }

    public List<CarModel> getModelsByBrand(String brand) {
        List<CarModel> list = new ArrayList<>();
        for (CarModel m : models)
            if (m.getBrand().equalsIgnoreCase(brand)) list.add(m);
        return list;
    }

    public CarModel findModel(String brand, String model) {
        for (CarModel m : models)
            if (m.getBrand().equalsIgnoreCase(brand) && m.getModel().equalsIgnoreCase(model))
                return m;
        return null;
    }
}
