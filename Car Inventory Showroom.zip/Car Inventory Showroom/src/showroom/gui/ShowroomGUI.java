package showroom.gui;

import showroom.model.*;
import showroom.service.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;
import java.util.*;
import java.util.List;
import java.util.stream.Stream;

public class ShowroomGUI extends JFrame {
    private InventoryService service;
    private JPanel mainPanel;

    public ShowroomGUI() {
        service = new InventoryService();
        setTitle("Car Showroom Inventory");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- Main Menu Panel Setup ---
        mainPanel = new JPanel();
        mainPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 50));

        JButton addModelBtn = new JButton("Add Model");
        JButton removeModelBtn = new JButton("Remove Model");
        JButton updateModelBtn = new JButton("Update Model");
        JButton viewModelBtn = new JButton("View Model");
        JButton sellCarBtn = new JButton("Sell Car");

        addModelBtn.setPreferredSize(new Dimension(200,50));
        removeModelBtn.setPreferredSize(new Dimension(200,50));
        updateModelBtn.setPreferredSize(new Dimension(200,50));
        viewModelBtn.setPreferredSize(new Dimension(200,50));
        sellCarBtn.setPreferredSize(new Dimension(200,50));

        mainPanel.add(addModelBtn);
        mainPanel.add(removeModelBtn);
        mainPanel.add(updateModelBtn);
        mainPanel.add(viewModelBtn);
        mainPanel.add(sellCarBtn);

        add(mainPanel, BorderLayout.CENTER);

        // --- Action Listeners ---
        addModelBtn.addActionListener(e -> showAddModel());
        removeModelBtn.addActionListener(e -> showRemoveModel());
        updateModelBtn.addActionListener(e -> showUpdateModel());
        viewModelBtn.addActionListener(e -> showViewModel());
        sellCarBtn.addActionListener(e -> showSellCar());

        setVisible(true);
    }

    // ---------------- Utility -----------------
    private void showMainMenu() {
        getContentPane().removeAll();
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        revalidate(); repaint();
    }

    /**
     * Updated to show files sorted by most recent time and use JFileChooser properly.
     * @param parent The parent frame for the dialog.
     * @return The absolute path of the chosen image file, or null.
     */
    private String chooseImage(JFrame parent) {
        JFileChooser chooser = new JFileChooser();
        
        // 1. Sort files by modified time (most recent first)
        chooser.setFileView(new javax.swing.filechooser.FileView() {
            @Override
            public String getName(File f) {
                if (f.isFile()) {
                    // Prepend modification time for sorting purposes, but this text won't be visible in standard look-and-feel
                    return String.format("%d|%s", f.lastModified(), f.getName());
                }
                return f.getName();
            }
        });
        
        // Use a custom comparator for files in the chooser if possible (though platform-dependent)
        // JFileChooser standard API does not guarantee easy custom sorting, but we can set the directory.
        // For standard JFileChooser, the best way is often to rely on the OS's default sorting or 
        // prompt the user to sort. We will ensure the starting directory is relevant.

        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.setFileFilter(new FileNameExtensionFilter("Images (jpg, jpeg, png)", "jpg", "jpeg", "png"));
        
        // Start in the user's home or a dedicated image folder
        File startDir = new File(System.getProperty("user.home"));
        // Attempt to start in the project's data/images folder if it exists
        File dataDir = new File("data/images");
        if(dataDir.exists() && dataDir.isDirectory()) {
            startDir = dataDir;
        }
        chooser.setCurrentDirectory(startDir);
        
        // Optional: Pre-select a file if images folder has recent files
        File[] imageFiles = dataDir.listFiles();
        if (imageFiles != null) {
            Optional<File> latestFile = Stream.of(imageFiles)
                .filter(File::isFile)
                .max(Comparator.comparing(File::lastModified));
            latestFile.ifPresent(chooser::setSelectedFile);
        }
        
        int res = chooser.showOpenDialog(parent);
        if(res == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile().getAbsolutePath();
        }
        return null;
    }

    private void copyNewImageAndDeleteOld(String srcPath, String destPath) throws Exception {
        // Create the directory if it doesn't exist
        File destFile = new File(destPath);
        destFile.getParentFile().mkdirs();
        
        if(destFile.exists()) destFile.delete();
        Files.copy(new File(srcPath).toPath(), destFile.toPath());
    }
    
    // Use the formatPrice from InventoryService for consistency
    private String formatPrice(double price) {
        return InventoryService.formatPrice(price);
    }


    // ---------------- Add Model -----------------
    private void showAddModel() {
        getContentPane().removeAll();
        JPanel panel = new JPanel(new GridLayout(6,2,10,10));

        JTextField txtBrand = new JTextField();
        JTextField txtModel = new JTextField();
        JTextField txtPrice = new JTextField();
        JTextField txtQty = new JTextField();
        JTextField txtImage = new JTextField();
        txtImage.setEditable(false); // Image path is selected via button
        JButton browseBtn = new JButton("Browse Image");

        panel.add(new JLabel("Brand:")); panel.add(txtBrand);
        panel.add(new JLabel("Model:")); panel.add(txtModel);
        panel.add(new JLabel("Price:")); panel.add(txtPrice);
        panel.add(new JLabel("Quantity:")); panel.add(txtQty);
        panel.add(new JLabel("Image Path:")); panel.add(txtImage);
        panel.add(new JLabel("")); panel.add(browseBtn);

        browseBtn.addActionListener(e -> {
            String path = chooseImage(this);
            if(path!=null) txtImage.setText(path);
        });

        JButton addBtn = new JButton("Add Model");
        JButton backBtn = new JButton("Back");

        JPanel bottom = new JPanel();
        bottom.add(addBtn); bottom.add(backBtn);

        addBtn.addActionListener(e -> {
            String brand = txtBrand.getText().trim();
            String model = txtModel.getText().trim();
            String priceStr = txtPrice.getText().trim();
            String qtyStr = txtQty.getText().trim();
            String imgPath = txtImage.getText().trim();

            if(brand.isEmpty() || model.isEmpty() || priceStr.isEmpty() || qtyStr.isEmpty() || imgPath.isEmpty()) {
                JOptionPane.showMessageDialog(this,"All fields required!");
                return;
            }

            try {
                double price = Double.parseDouble(priceStr);
                int qty = Integer.parseInt(qtyStr);
                
                if (price <= 0 || qty <= 0) {
                     JOptionPane.showMessageDialog(this,"Price and Quantity must be greater than zero!");
                     return;
                }

                // Check if model already exists
                if (service.getCarModel(brand, model) != null) {
                    JOptionPane.showMessageDialog(this,"Model already exists! Use Update Model.");
                    return;
                }

                // copy image to data/images
                String destPath = "data/images/"+brand.toLowerCase().replaceAll("\\s+","_")+"_"+model.toLowerCase().replaceAll("\\s+","_")+".png";
                copyNewImageAndDeleteOld(imgPath,destPath);

                CarModel newModel = new CarModel(brand, model, price, qty, destPath);
                service.addCarModel(newModel);
                
                JOptionPane.showMessageDialog(this,"Model Added Successfully! " + brand + " " + model);
                showMainMenu();
            } catch(NumberFormatException ex){ 
                JOptionPane.showMessageDialog(this,"Invalid numeric input for Price or Quantity!"); 
            } catch(Exception ex){
                 JOptionPane.showMessageDialog(this,"Error saving image: " + ex.getMessage());
            }
        });

        backBtn.addActionListener(e -> showMainMenu());

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(panel), BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);
        revalidate();
        repaint();
    }

    // ---------------- Remove Model (and helpers) -----------------
    private void showRemoveModel() {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showMainMenu());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        List<String> brands = service.getAllBrands();

        JPanel brandPanel = new JPanel(new FlowLayout());
        if (brands.isEmpty()) {
            brandPanel.add(new JLabel("No car models in inventory."));
        } else {
            for(String brand: brands) {
                JButton bBtn = new JButton(brand);
                bBtn.addActionListener(e -> showRemoveModelByBrand(brand));
                brandPanel.add(bBtn);
            }
        }

        getContentPane().add(new JScrollPane(brandPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showRemoveModelByBrand(String brand) {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showRemoveModel());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        JPanel modelPanel = new JPanel(new FlowLayout());
        List<CarModel> models = service.getModelsByBrand(brand);

        for(CarModel modelObj: models) {
            JButton mBtn = new JButton();
            String model = modelObj.getModel();
            String imgPath = modelObj.getImagePath();
            
            ImageIcon icon = new ImageIcon(imgPath);
            Image scaled = icon.getImage().getScaledInstance(150,100,Image.SCALE_SMOOTH);
            mBtn.setIcon(new ImageIcon(scaled));
            mBtn.setText(model);
            mBtn.setHorizontalTextPosition(SwingConstants.CENTER);
            mBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
            mBtn.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(this,"Delete entire model "+model+"?","Confirm",JOptionPane.YES_NO_OPTION);
                if(confirm==JOptionPane.YES_OPTION) {
                    service.removeCarModel(brand,model);
                    
                    // delete image
                    File oldImg = new File(imgPath);
                    if(oldImg.exists()) oldImg.delete();
                    
                    JOptionPane.showMessageDialog(this,"Model Removed Successfully!");
                    showRemoveModel(); // Refresh the brand list
                }
            });
            modelPanel.add(mBtn);
        }

        getContentPane().add(new JScrollPane(modelPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    // ---------------- Update Model (and helpers) -----------------
    private void showUpdateModel() {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showMainMenu());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        List<String> brands = service.getAllBrands();

        JPanel brandPanel = new JPanel(new FlowLayout());
        if (brands.isEmpty()) {
            brandPanel.add(new JLabel("No car models in inventory to update."));
        } else {
            for(String brand: brands) {
                JButton bBtn = new JButton(brand);
                bBtn.addActionListener(e -> showUpdateModelByBrand(brand));
                brandPanel.add(bBtn);
            }
        }

        getContentPane().add(new JScrollPane(brandPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showUpdateModelByBrand(String brand) {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showUpdateModel());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        JPanel modelPanel = new JPanel(new FlowLayout());
        List<CarModel> models = service.getModelsByBrand(brand);

        for(CarModel modelObj: models) {
            JButton mBtn = new JButton();
            String model = modelObj.getModel();
            String imgPath = modelObj.getImagePath();
            
            ImageIcon icon = new ImageIcon(imgPath);
            Image scaled = icon.getImage().getScaledInstance(150,100,Image.SCALE_SMOOTH);
            mBtn.setIcon(new ImageIcon(scaled));
            mBtn.setText(model);
            mBtn.setHorizontalTextPosition(SwingConstants.CENTER);
            mBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
            mBtn.addActionListener(e -> showUpdateForm(brand,model));
            modelPanel.add(mBtn);
        }
        getContentPane().add(new JScrollPane(modelPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showUpdateForm(String brand, String model) {
        getContentPane().removeAll();
        // Use getCarModel which returns CarModel
        CarModel carModel = service.getCarModel(brand,model); 
        
        if (carModel == null) {
            JOptionPane.showMessageDialog(this,"Model not found!");
            showUpdateModelByBrand(brand);
            return;
        }

        JPanel panel = new JPanel(new GridLayout(6,2,10,10));
        JTextField txtBrand = new JTextField(carModel.getBrand());
        JTextField txtModel = new JTextField(carModel.getModel());
        // Show price and quantity as string
        JTextField txtPrice = new JTextField(String.valueOf(carModel.getPrice())); 
        JTextField txtQty = new JTextField(String.valueOf(carModel.getQuantity()));
        JTextField txtImage = new JTextField(carModel.getImagePath());
        txtImage.setEditable(false);
        JButton browseBtn = new JButton("Browse Image");
        
        // Brand and Model should be immutable in the form to avoid complex key changes, 
        // but the Service method allows changing them, so we'll keep them editable.
        // For simplicity, we'll allow changes and handle the primary key update in the service.

        panel.add(new JLabel("Brand:")); panel.add(txtBrand);
        panel.add(new JLabel("Model:")); panel.add(txtModel);
        panel.add(new JLabel("Price:")); panel.add(txtPrice);
        panel.add(new JLabel("Quantity:")); panel.add(txtQty);
        panel.add(new JLabel("Image Path:")); panel.add(txtImage);
        panel.add(new JLabel("")); panel.add(browseBtn);

        browseBtn.addActionListener(e -> {
            String path = chooseImage(this);
            if(path!=null) txtImage.setText(path);
        });

        JButton updateBtn = new JButton("Update");
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showUpdateModelByBrand(brand));

        JPanel bottom = new JPanel(); bottom.add(updateBtn); bottom.add(backBtn);

        updateBtn.addActionListener(e -> {
            try {
                String oldBrand = carModel.getBrand();
                String oldModel = carModel.getModel();
                String oldImagePath = carModel.getImagePath();

                String newBrand = txtBrand.getText().trim();
                String newModel = txtModel.getText().trim();
                double price = Double.parseDouble(txtPrice.getText().trim());
                int qty = Integer.parseInt(txtQty.getText().trim());
                String imgPath = txtImage.getText().trim();
                
                if (price <= 0 || qty < 0) {
                     JOptionPane.showMessageDialog(this,"Price must be positive and Quantity non-negative!");
                     return;
                }

                // Determine the new final image path
                String destPath = "data/images/"+newBrand.toLowerCase().replaceAll("\\s+","_")+"_"+newModel.toLowerCase().replaceAll("\\s+","_")+".png";
                
                // Only copy/replace image if a new image was selected (i.e., imgPath is different from the carModel's saved path)
                // OR if the brand/model name changed, requiring a new file name.
                if (!imgPath.equals(oldImagePath) || !oldBrand.equalsIgnoreCase(newBrand) || !oldModel.equalsIgnoreCase(newModel)) {
                    // If a new file was chosen (imgPath != oldImagePath), copy it.
                    if (!imgPath.equals(oldImagePath)) {
                        copyNewImageAndDeleteOld(imgPath,destPath);
                    } else {
                        // If no new image was chosen, but brand/model changed, rename the existing file.
                        // For simplicity in the GUI, we'll let the service handle the data update.
                        // The service should be responsible for renaming the file if keys change, but since 
                        // the service doesn't have a rename method, we'll stick to a simple copy/replace logic
                        // and ensure the final path is correct.
                        // For this update, we will simply use the newly constructed destPath if the model/brand changes,
                        // assuming a copy/delete operation is safe if the source and destination are the same (which Files.copy handles).
                    }
                } else {
                    destPath = oldImagePath; // Keep the old destination path if nothing related to image/keys changed
                }

                // Check if updating to an existing model (except self)
                CarModel existingModel = service.getCarModel(newBrand, newModel);
                if (existingModel != null && existingModel != carModel) {
                     JOptionPane.showMessageDialog(this,"A model with that Brand and Model name already exists!");
                     return;
                }

                service.updateCarModel(carModel, newBrand, newModel, price, qty, destPath);

                JOptionPane.showMessageDialog(this,"Updated Successfully! " + newBrand + " " + newModel);
                showMainMenu();
            } catch(NumberFormatException ex){ 
                JOptionPane.showMessageDialog(this,"Invalid numeric input for Price or Quantity!"); 
            } catch(Exception ex){
                 JOptionPane.showMessageDialog(this,"Error saving image: " + ex.getMessage());
            }
        });

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(panel), BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);
        revalidate(); repaint();
    }

    // ---------------- View Model (and helpers) -----------------
    private void showViewModel() {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showMainMenu());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        List<String> brands = service.getAllBrands();

        JPanel brandPanel = new JPanel(new FlowLayout());
        if (brands.isEmpty()) {
            brandPanel.add(new JLabel("No car models in inventory to view."));
        } else {
            for(String brand: brands) {
                JButton bBtn = new JButton(brand);
                bBtn.addActionListener(e -> showViewModelByBrand(brand));
                brandPanel.add(bBtn);
            }
        }

        getContentPane().add(new JScrollPane(brandPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showViewModelByBrand(String brand) {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showViewModel());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        JPanel modelPanel = new JPanel(new FlowLayout());
        List<CarModel> models = service.getModelsByBrand(brand);

        for(CarModel modelObj: models) {
            JButton mBtn = new JButton();
            String model = modelObj.getModel();
            String imgPath = modelObj.getImagePath();
            
            ImageIcon icon = new ImageIcon(imgPath);
            Image scaled = icon.getImage().getScaledInstance(150,100,Image.SCALE_SMOOTH);
            mBtn.setIcon(new ImageIcon(scaled));
            mBtn.setText(model);
            mBtn.setHorizontalTextPosition(SwingConstants.CENTER);
            mBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
            mBtn.addActionListener(e -> showModelDetails(brand,model));
            modelPanel.add(mBtn);
        }
        getContentPane().add(new JScrollPane(modelPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showModelDetails(String brand, String model) {
        getContentPane().removeAll();
        CarModel carModel = service.getCarModel(brand,model);
        
        if (carModel == null) {
            JOptionPane.showMessageDialog(this,"Model not found!");
            showViewModelByBrand(brand);
            return;
        }
        
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showViewModelByBrand(brand));

        JLabel lblImage = new JLabel();
        ImageIcon icon = new ImageIcon(carModel.getImagePath());
        Image scaled = icon.getImage().getScaledInstance(300,200,Image.SCALE_SMOOTH);
        lblImage.setIcon(new ImageIcon(scaled));

        JPanel info = new JPanel(new GridLayout(4,1));
        info.add(new JLabel("Brand: "+carModel.getBrand()));
        info.add(new JLabel("Model: "+carModel.getModel()));
        info.add(new JLabel("Price: "+formatPrice(carModel.getPrice())));
        info.add(new JLabel("Quantity: "+carModel.getQuantity())); // Quantity is directly on CarModel

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(backBtn, BorderLayout.NORTH);
        getContentPane().add(lblImage, BorderLayout.CENTER);
        getContentPane().add(info, BorderLayout.SOUTH);

        revalidate(); repaint();
    }

    // ---------------- Sell Car (and helpers) -----------------
    private void showSellCar() {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showMainMenu());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        List<String> brands = service.getAllBrands();

        JPanel brandPanel = new JPanel(new FlowLayout());
        if (brands.isEmpty()) {
            brandPanel.add(new JLabel("No car models available for sale."));
        } else {
            for(String brand: brands) {
                JButton bBtn = new JButton(brand);
                bBtn.addActionListener(e -> showSellModelByBrand(brand));
                brandPanel.add(bBtn);
            }
        }

        getContentPane().add(new JScrollPane(brandPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showSellModelByBrand(String brand) {
        getContentPane().removeAll();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showSellCar());
        getContentPane().add(backBtn, BorderLayout.NORTH);

        JPanel modelPanel = new JPanel(new FlowLayout());
        List<CarModel> models = service.getModelsByBrand(brand);

        for(CarModel modelObj: models) {
            JButton mBtn = new JButton();
            String model = modelObj.getModel();
            String imgPath = modelObj.getImagePath();
            
            ImageIcon icon = new ImageIcon(imgPath);
            Image scaled = icon.getImage().getScaledInstance(150,100,Image.SCALE_SMOOTH);
            mBtn.setIcon(new ImageIcon(scaled));
            mBtn.setText(model + " ("+modelObj.getQuantity()+")"); // Show quantity on button
            mBtn.setHorizontalTextPosition(SwingConstants.CENTER);
            mBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
            mBtn.addActionListener(e -> showSellPage(brand,model));
            modelPanel.add(mBtn);
        }

        getContentPane().add(new JScrollPane(modelPanel), BorderLayout.CENTER);
        revalidate(); repaint();
    }

    private void showSellPage(String brand, String model) {
        getContentPane().removeAll();
        CarModel carModel = service.getCarModel(brand,model);

        if (carModel == null) {
            JOptionPane.showMessageDialog(this,"Model not found!");
            showSellModelByBrand(brand);
            return;
        }

        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> showSellModelByBrand(brand));

        JLabel lblImage = new JLabel();
        ImageIcon icon = new ImageIcon(carModel.getImagePath());
        Image scaled = icon.getImage().getScaledInstance(300,200,Image.SCALE_SMOOTH);
        lblImage.setIcon(new ImageIcon(scaled));

        JPanel info = new JPanel(new GridLayout(4,1));
        info.add(new JLabel("Brand: "+carModel.getBrand()));
        info.add(new JLabel("Model: "+carModel.getModel()));
        info.add(new JLabel("Price: "+formatPrice(carModel.getPrice())));
        info.add(new JLabel("Quantity: "+carModel.getQuantity()));

        JButton sellBtn = new JButton("Sell One Unit");
        
        // Disable sell button if quantity is 0
        if (carModel.getQuantity() <= 0) {
            sellBtn.setEnabled(false);
            sellBtn.setText("OUT OF STOCK");
        }

        sellBtn.addActionListener(e -> {
            int originalQuantity = carModel.getQuantity();
            
            // The service handles the quantity check and decrement
            service.sellCar(brand,model);
            
            // Get the updated quantity (either 1 less or 0 if it was 0)
            CarModel updatedCarModel = service.getCarModel(brand, model);
            
            if (updatedCarModel != null && updatedCarModel.getQuantity() < originalQuantity) {
                // SUCCESS: Quantity decreased
                JOptionPane.showMessageDialog(this,"Car Sold! Remaining: " + updatedCarModel.getQuantity());
            } else {
                // FAILURE: Quantity did not decrease (must have been 0)
                 JOptionPane.showMessageDialog(this,"Sale Failed. No cars available to sell for this model.");
            }
            showMainMenu();
        });

        JPanel bottom = new JPanel(); bottom.add(sellBtn);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(backBtn, BorderLayout.NORTH);
        getContentPane().add(lblImage, BorderLayout.CENTER);
        getContentPane().add(info, BorderLayout.WEST);
        getContentPane().add(bottom, BorderLayout.SOUTH);
        revalidate(); repaint();
    }

    public static void main(String[] args) {
        // Use SwingUtilities.invokeLater for thread safety
        SwingUtilities.invokeLater(() -> new ShowroomGUI());
    }
}